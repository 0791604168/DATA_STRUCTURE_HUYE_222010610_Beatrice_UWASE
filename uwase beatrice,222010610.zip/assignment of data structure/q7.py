# Q7.Store and display the weekly sales of different products in a shop in a 2D array (products x days).
    
# Rows represent products and columns represent days (e.g.,Bananas, Mangoes, Tomatoes, sales for 7 days)
weekly_sales = [
    [45, 65, 62, 23, 12, 61, 82], 
    [86, 23, 19, 65, 45, 5, 87],      
    [67, 12, 23, 34, 45, 23, 65]
]

# Product names
products = ["Bananas", "Mangoes", "Tomatoes"]

# Display the weekly sales for each product
print("Weekly Sales (Products x Days):")
for i, product_sales in enumerate(weekly_sales):
    print(f"{products[i]} sales: {product_sales}")
    
    