# Q3. 

ages_list = [23, 12, 14, 32, 10]
# sorting ages
ages_list.sort()
print("sorted ages using the sorted():", ages_list)

