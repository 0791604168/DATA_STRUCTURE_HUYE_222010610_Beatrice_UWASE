# Q9.
# List of product details: [name, price, stock]
products = [
    ["Shoes", 230.0, 54],
    ["Watch", 111.0, 23],
    ["Mouse", 231.0, 30],
    ["Telephone", 150.0, 12],
    ["Dors", 35.0, 95]
]

# Display the product list
for product in products:
    print(f"Product: {product[0]}, Price: ${product[1]:.3f}, Stock: {product[2]}")
    
    