
    
    
    # Finding total marks of students
# Rows represent students and columns represent marks in subjects CHM, BIO, AND ICT
marks = [
    [65, 86, 98],  # Marks of James
    [76, 56, 76],  # Marks for Peter
    [78, 66, 90],  # Marks for Age
]

# Calculate total marks for each student
total_marks = []
for student in marks:
    total_marks.append(sum(student))

# Print total marks for each student
for i, total in enumerate(total_marks, start=1):
    print(f"Total marks for Student {i}: {total}")