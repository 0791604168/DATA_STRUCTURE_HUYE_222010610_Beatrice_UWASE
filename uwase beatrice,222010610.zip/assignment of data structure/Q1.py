#ONE-DIMENSIONAL ARRAYS (SINGLE-DIMENSIONAL ARRAYS):

# Q1. 1.Store and print the temperature readings of a city for 7 days.

temperature_reading = [23, 33, 26, 36, 39, 24, 28]
print(temperature_reading)
print(f"temperature reading): ℃({temperature_reading}")

