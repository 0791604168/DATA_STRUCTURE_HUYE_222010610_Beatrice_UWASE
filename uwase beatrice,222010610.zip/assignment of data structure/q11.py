# ONDE_DIMENTIONAL_LIST

# Q1.

attendees = ["Adolphe", "Evode", "Bernard", "John"]

# Display the current list of attendees
print("Attendees:", attendees)

# Adding a new name to the list
new_attendee = "Kalisa"
attendees.append(new_attendee)

# Display the updated list of attendees
print("Updated Attendees:", attendees)
