# Q10.
    
    
    # List of scores in different games for players: [Player Name, Game 1 Score, Game 2 Score, Game 3 Score]
scores = [
    ["Memory", 43, 90, 93],
    ["kanani", 54, 92, 12],
    ["Beatha", 89, 85, 90],
    ["Musa", 70, 75, 80],
    ["Bernard", 95, 89, 120]
]
