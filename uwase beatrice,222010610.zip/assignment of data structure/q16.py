#Q6.  


# Create a list of lists where each sublist contains the name, age, and grade of students
students = [
    ["Ange", 20, 85],
    ["Tomas", 22, 90],
    ["james", 21, 75],
    ["Patrick", 23, 80]
]

# Sort the list by the grade (which is the third element in each sublist)
sorted_students = sorted(students, key=lambda student: student[2])

# Display the sorted list
print("Sorted list by grade:")
for student in sorted_students:
    print(f"Name: {student[0]}, Age: {student[1]}, Grade: {student[2]}")

