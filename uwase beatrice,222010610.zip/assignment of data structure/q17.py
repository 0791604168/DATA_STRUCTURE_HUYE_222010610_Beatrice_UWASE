#Q7?


# My category list for 6 monthly expenses
# MY PRODUCT: Rent, Food, Utility
expenses = [
    [420, 530, 560, ],  # Month 1
    [123, 800, 400, ],  # Month 2
    [650, 310, 165, ],  # Month 3
    [560, 290, 230, ],  # Month 4
    [240, 305, 800, ],  # Month 5
    [370, 315, 680, ],  # Month 6
]

# Transposing the list to group by category (so we can calculate average per category)
expenses_by_category = list(zip(*expenses))

# Calculating the average expense per category
average_expenses = [sum(category) / len(category) for category in expenses_by_category]
print("average expences for each category:", average_expenses)




