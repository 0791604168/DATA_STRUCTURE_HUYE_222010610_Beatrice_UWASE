# Initially, all seats are marked as 'Available'
rows, seats_per_row = 5, 6
theater_seating = [['Available' for _ in range(seats_per_row)] for _ in range(rows)]

# Function to reserve a seat
def reserve_seat(row, seat):
    if theater_seating[row][seat] == 'Available':
        theater_seating[row][seat] = 'Reserved'
    else:
        return "Seat already reserved!"

# Assigning reserved seats
reserve_seat(0, 1)  # Reserve seat in row 0, seat 1
reserve_seat(2, 3)  # Reserve seat in row 2, seat 3
reserve_seat(4, 5)  # Reserve seat in row 4, seat 5

print(theater_seating)