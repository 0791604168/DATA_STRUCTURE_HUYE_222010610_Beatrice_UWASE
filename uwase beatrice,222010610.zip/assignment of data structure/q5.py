# Q5. Count the number of even and odd numbers in a list of random numbers.

import random

# Generate a list of random numbers
random_numbers = [random.randint(1, 100) for _ in range(30)]

# Initialize counters
even_count = 0
odd_count = 0

# Count even and odd numbers
for number in random_numbers:
    if number % 2 == 0:
        even_count += 1
    else:
        odd_count += 1

# Output the results
print("Random Numbers:", random_numbers)
print("Even Count:", even_count)
print("Odd Count:", odd_count)


