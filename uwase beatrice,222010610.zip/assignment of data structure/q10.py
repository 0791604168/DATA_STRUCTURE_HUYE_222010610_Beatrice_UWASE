# Q10. 
    
    temperature_reading = [
        [23, 32, 12, 38, 29, 30, 34],  # city 1
        [32, 34, 28, 31, 30, 29, 21],  # city 2
        [33, 32, 23, 11, 34, 33, 20],  # city 3
        [27, 30, 12, 33, 20, 19, 39]   # city 4
    ]
    total_temperature_reading = []
    for average_temperature in temperature_reading
    sum_city1 = sum(int.temperature_reading[1])
    

