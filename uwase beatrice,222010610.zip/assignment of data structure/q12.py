# Q2. Create a shopping list, then remove an item from the list.

shoping_list =['bananas','mangoes', 'juice', 'milk']
print(shoping_list)
# removing items
shoping_list.remove('mangoes')
print(shoping_list)

