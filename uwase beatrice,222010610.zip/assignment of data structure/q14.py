# Q4. 

# Initialize the to-do list
todo_list = []

# Function to add a task
def add_task(task):
    todo_list.append(task)
    print(f"Added task: '{task}'")

# Function to remove a task
def complete_task(task):
    if task in todo_list:
        todo_list.remove(task)
        print(f"Completed task: '{task}'")
    else:
        print(f"Task '{task}' not found in the list.")

# Function to display the to-do list
def display_tasks():
    if todo_list:
        print("To-Do List:")
        for task in todo_list:
            print(f"- {task}")
    else:
        print("The to-do list is empty.")

# Example usage
add_task("Buy groceries")
add_task("Clean the house")
add_task("Finish homework")

display_tasks()

# Mark a task as completed
complete_task("Clean the house")

# Display the updated to-do list
display_tasks()