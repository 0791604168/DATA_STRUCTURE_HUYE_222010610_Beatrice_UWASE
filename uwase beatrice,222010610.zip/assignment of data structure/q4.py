# Q4. 4.Reverse the order of an array of student marks in a subject.

student_marks = [66, 51, 16, 76]
student_marks.reverse()
print(student_marks)